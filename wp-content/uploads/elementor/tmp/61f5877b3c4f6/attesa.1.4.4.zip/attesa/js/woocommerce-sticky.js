(function ($) {
	'use strict';
	$(window).on('load', function () {
		/* ----------------------------------------------------------------------------------- */
		/* Sticky woocommerce bar */
		/* ----------------------------------------------------------------------------------- */
		if ($('.attesa-woocommerce-sticky-product').length) {
			$(window).scroll(function () {
				var d = $('.woocommerce .content-area .summary').offset().top - $('header.site-header').outerHeight(),
					z = $('.woocommerce .content-area .summary').height(),
					y = $('.footer-bottom-area').offset().top,
					wS = $(window).scrollTop(),
					wH = $(window).height();
				if ( wS >= d + z && wS < (y-wH) ) {
					$('.attesa-woocommerce-sticky-product').addClass('slideInUp');
					$('.attesa-woocommerce-sticky-product').removeClass('slideOutDown');
				} else {
					$('.attesa-woocommerce-sticky-product').removeClass('slideInUp');
					$('.attesa-woocommerce-sticky-product').addClass('slideOutDown');
				}
			});
			$('.attesa-woocommerce-sticky-product .attesa-sticky-button').click(function(){
				$('html,body').animate({ scrollTop: $('.woocommerce div.product').offset().top - $('header.site-header').outerHeight() - 30 }, 500);
				return false;
			});
		}
	});
})(jQuery);
